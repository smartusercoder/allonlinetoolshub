export interface FAQ {
  question: string;
  answer: string;
}

export const toolFAQs: Record<string, FAQ[]> = {
  "word-counter": [
    {
      question: "How does the word counter work?",
      answer: "The word counter analyzes your text in real-time and counts the number of words, characters, sentences, and paragraphs. Simply paste or type your text into the input field, and the results are calculated instantly without storing any data."
    },
    {
      question: "Does the word counter work for all languages?",
      answer: "Yes, our word counter supports all languages including English, Spanish, French, German, Chinese, Japanese, and many more. It accurately counts words and characters regardless of the language or alphabet used."
    },
    {
      question: "Is the word counter free to use?",
      answer: "Yes, our word counter is completely free to use with no registration required. There are no limits on how many times you can use it or how much text you can analyze."
    },
    {
      question: "Does the word counter save my text?",
      answer: "No, all processing is done locally in your browser. Your text is never uploaded to our servers or stored anywhere. Your privacy and data security are completely protected."
    },
    {
      question: "Can I count words in a PDF or Word document?",
      answer: "You can copy and paste text from PDF or Word documents directly into the word counter. The tool will then count all words, characters, sentences, and paragraphs from the pasted content."
    }
  ],
  "bmi-calculator": [
    {
      question: "What is BMI and how is it calculated?",
      answer: "BMI (Body Mass Index) is a measure of body fat based on height and weight. It's calculated by dividing weight in kilograms by height in meters squared (kg/m²). For imperial units, it's weight in pounds divided by height in inches squared, multiplied by 703."
    },
    {
      question: "What is a healthy BMI range?",
      answer: "A healthy BMI typically ranges from 18.5 to 24.9. Below 18.5 is considered underweight, 25 to 29.9 is overweight, and 30 or above is considered obese. However, BMI is just one indicator and should be considered alongside other health factors."
    },
    {
      question: "Is BMI accurate for everyone?",
      answer: "BMI is a useful general indicator but has limitations. It may not be accurate for athletes with high muscle mass, elderly people, pregnant women, or children. It also doesn't account for bone density, muscle mass, or fat distribution."
    },
    {
      question: "How often should I check my BMI?",
      answer: "For adults maintaining a stable weight, checking BMI every few months is sufficient. If you're actively trying to lose or gain weight, weekly or bi-weekly checks can help track progress alongside other health metrics."
    },
    {
      question: "Can I use BMI calculator for children?",
      answer: "While you can calculate BMI for children, interpreting it requires different standards. Children's BMI is compared to growth charts specific to age and gender. Consult a pediatrician for accurate assessment of a child's healthy weight range."
    }
  ],
  "password-generator": [
    {
      question: "How secure are generated passwords?",
      answer: "Our password generator creates highly secure passwords using cryptographically secure random number generation. Passwords include a mix of uppercase, lowercase, numbers, and symbols, making them extremely difficult to crack."
    },
    {
      question: "What makes a strong password?",
      answer: "A strong password is at least 12 characters long, includes uppercase and lowercase letters, numbers, and special symbols, avoids dictionary words or personal information, and is unique for each account."
    },
    {
      question: "Are the generated passwords stored anywhere?",
      answer: "No, all passwords are generated locally in your browser and are never sent to or stored on our servers. The password exists only in your browser session until you copy it or close the page."
    },
    {
      question: "How long should my password be?",
      answer: "We recommend passwords of at least 12-16 characters. Longer passwords (20+ characters) are even more secure. The length significantly increases the time needed to crack a password through brute force attacks."
    },
    {
      question: "Should I use different passwords for each account?",
      answer: "Yes, absolutely. Using unique passwords for each account prevents a single data breach from compromising all your accounts. Use a password manager to securely store and manage different passwords for each service."
    }
  ],
  "qr-code-generator": [
    {
      question: "What can I encode in a QR code?",
      answer: "QR codes can encode URLs, text, contact information (vCard), WiFi credentials, email addresses, phone numbers, SMS messages, and more. Our generator supports all common QR code data types."
    },
    {
      question: "Is there a size limit for QR codes?",
      answer: "QR codes can store up to approximately 4,296 alphanumeric characters or 7,089 numeric characters. However, more data creates more complex codes that may be harder to scan. We recommend keeping data concise for best results."
    },
    {
      question: "Can QR codes expire?",
      answer: "Static QR codes (like those generated by our tool) never expire. Once created, they work indefinitely. However, if the QR code links to a URL and that website goes down, the QR code will no longer work properly."
    },
    {
      question: "What's the best size to print a QR code?",
      answer: "The minimum recommended size is 2 x 2 cm (0.8 x 0.8 inches) for close-range scanning. For scanning from a distance, larger sizes are better. Ensure there's adequate white space (quiet zone) around the QR code for reliable scanning."
    },
    {
      question: "Can I customize QR code colors?",
      answer: "Yes, you can customize QR code colors. However, ensure high contrast between the foreground and background (typically dark on light). Avoid light colors on light backgrounds as this reduces scannability."
    }
  ],
  "image-compressor": [
    {
      question: "How much can I compress an image without losing quality?",
      answer: "You can typically compress images by 50-70% without noticeable quality loss for web use. Our tool uses smart compression algorithms that preserve visual quality while significantly reducing file size."
    },
    {
      question: "What's the difference between lossy and lossless compression?",
      answer: "Lossless compression reduces file size without any quality loss, while lossy compression achieves greater size reduction by discarding some image data. For photos, lossy (JPEG) is usually fine; for graphics with text, lossless (PNG) is better."
    },
    {
      question: "Does compressing images affect resolution?",
      answer: "Image compression reduces file size by optimizing how image data is stored, not by changing resolution (dimensions). To change resolution, use our image resizer tool. Compression maintains the same pixel dimensions with smaller file size."
    },
    {
      question: "What image formats can I compress?",
      answer: "Our compressor supports JPEG, PNG, WebP, and GIF formats. Each format uses different compression techniques optimized for its specific use case (photos, graphics, animations, etc.)."
    },
    {
      question: "Are my uploaded images stored on your server?",
      answer: "No, all image processing happens locally in your browser. Your images are never uploaded to our servers. This ensures complete privacy and security of your photos and graphics."
    }
  ],
  "json-formatter": [
    {
      question: "What is JSON formatting?",
      answer: "JSON formatting (or beautifying) adds proper indentation, line breaks, and spacing to make JSON data human-readable. It transforms minified JSON into an organized, easy-to-read structure without changing the data."
    },
    {
      question: "Can the JSON formatter fix errors?",
      answer: "Our JSON formatter includes validation that identifies syntax errors like missing brackets, incorrect commas, or invalid formatting. While it highlights errors, you'll need to manually fix the issues in the JSON structure."
    },
    {
      question: "What's the difference between minify and beautify?",
      answer: "Beautify adds formatting (spaces, line breaks, indentation) to make JSON readable for humans. Minify removes all unnecessary whitespace to create the smallest possible file size, ideal for production use or data transfer."
    },
    {
      question: "Is there a size limit for JSON files?",
      answer: "Our JSON formatter can handle large JSON files, but browser memory limitations may affect very large files (100MB+). For best performance, we recommend files under 10MB. Processing happens locally, so your browser's capabilities determine the limit."
    },
    {
      question: "Can I format JSON from an API response?",
      answer: "Yes, you can copy JSON from any API response and paste it into our formatter. This is helpful for debugging API calls, understanding response structures, and developing applications that consume APIs."
    }
  ],
  "pdf-merge": [
    {
      question: "How many PDF files can I merge at once?",
      answer: "You can merge multiple PDF files in a single operation. There's no strict limit, though browser performance may be affected with very large files or many documents. Merging is done locally in your browser."
    },
    {
      question: "Does merging PDFs reduce quality?",
      answer: "No, merging PDFs does not reduce quality. The original content, images, and formatting of each PDF are preserved exactly as they were. The merged PDF maintains the same quality as the source files."
    },
    {
      question: "Can I change the order of PDFs before merging?",
      answer: "Yes, you can drag and drop to reorder PDFs before merging them. This allows you to arrange documents in your preferred sequence before creating the final merged PDF file."
    },
    {
      question: "Are my PDFs stored on your server?",
      answer: "No, all PDF processing happens locally in your browser. Your files are never uploaded to our servers, ensuring complete privacy and security for your documents."
    },
    {
      question: "What's the maximum file size I can merge?",
      answer: "The maximum size depends on your browser's capabilities. Most modern browsers can handle several hundred megabytes. For very large files, processing may take longer but will complete locally in your browser."
    }
  ],
  "base64-encoder": [
    {
      question: "What is Base64 encoding?",
      answer: "Base64 encoding is a method to convert binary data into ASCII text format. It's commonly used to embed images in HTML/CSS, transmit data over text-based protocols, or store binary data in JSON/XML."
    },
    {
      question: "When should I use Base64 encoding?",
      answer: "Use Base64 for embedding small images in CSS/HTML, including images in JSON APIs, storing binary data in text-only databases, or transmitting binary data through text-based systems like email or XML."
    },
    {
      question: "Does Base64 increase file size?",
      answer: "Yes, Base64 encoding increases data size by approximately 33%. While convenient for embedding, it's not efficient for large files. For large images or files, direct file hosting is usually better than Base64 encoding."
    },
    {
      question: "Is Base64 encoding secure?",
      answer: "Base64 is encoding, not encryption. It makes data unreadable to casual observers but offers no security. Anyone can decode Base64 data. For security, use proper encryption methods, not Base64 encoding."
    },
    {
      question: "Can I encode any file type to Base64?",
      answer: "Yes, any file type (images, documents, audio, video, etc.) can be Base64 encoded. However, it's most practical for small files like icons, thumbnails, or data that needs to be embedded in text formats."
    }
  ],
  "calculator": [
    {
      question: "Does the calculator follow the order of operations?",
      answer: "Yes, our calculator follows the standard mathematical order of operations (PEMDAS/BODMAS): Parentheses, Exponents, Multiplication and Division (left to right), Addition and Subtraction (left to right)."
    },
    {
      question: "Can I use keyboard to enter numbers?",
      answer: "Yes, you can use your keyboard's number pad and operation keys to perform calculations. This makes it faster and more convenient than clicking buttons for complex calculations."
    },
    {
      question: "Does the calculator save my calculation history?",
      answer: "The calculator displays your current calculation, but history is not permanently stored. All calculations are processed locally in your browser and are cleared when you close the page or clear your calculation."
    },
    {
      question: "Can I copy the calculation result?",
      answer: "Yes, you can select and copy the result displayed on the calculator. This allows you to easily paste the calculated value into other applications or documents."
    },
    {
      question: "What's the precision of the calculator?",
      answer: "Our calculator provides high precision for most everyday calculations. For extremely large numbers or very precise scientific calculations, consider using our scientific calculator which offers additional precision and functions."
    }
  ],
  "case-converter": [
    {
      question: "What case conversion options are available?",
      answer: "Our case converter supports multiple formats: UPPERCASE, lowercase, Title Case, Sentence case, camelCase, PascalCase, snake_case, kebab-case, and more. Choose the format that fits your needs."
    },
    {
      question: "Does the case converter work for all languages?",
      answer: "Yes, the case converter works with all languages that have uppercase and lowercase letters. It properly handles accented characters, special characters, and non-English alphabets."
    },
    {
      question: "Can I convert large amounts of text?",
      answer: "Yes, there's no strict limit on text length. You can convert entire documents, articles, or code files. Processing is instant and happens locally in your browser."
    },
    {
      question: "What's the difference between Title Case and Sentence case?",
      answer: "Title Case capitalizes the first letter of each major word (e.g., 'This Is Title Case'), while Sentence case only capitalizes the first letter of each sentence (e.g., 'This is sentence case. Another sentence here.')."
    },
    {
      question: "Is my text saved anywhere?",
      answer: "No, all text processing happens locally in your browser. Your text is never sent to or stored on our servers, ensuring complete privacy and security."
    }
  ],
  "image-resizer": [
    {
      question: "How do I resize an image without losing quality?",
      answer: "Use our image resizer with 'Maintain Aspect Ratio' enabled to prevent distortion. For best results, only reduce size (downscaling) as upscaling can cause blurriness. Our tool uses advanced algorithms to preserve maximum quality."
    },
    {
      question: "What's the maximum image size I can resize?",
      answer: "Our resizer handles images up to 10MB in size. For larger images, consider compressing first or using desktop software. All processing happens in your browser, so your computer's memory affects the maximum size."
    },
    {
      question: "Can I resize multiple images at once?",
      answer: "Currently, our tool processes one image at a time for optimal quality control. You can quickly resize multiple images by processing them sequentially—each takes just seconds."
    },
    {
      question: "What image formats are supported?",
      answer: "Our resizer supports JPEG, PNG, WebP, and GIF formats. You can also convert between formats while resizing if needed using our image converter tool."
    },
    {
      question: "Does resizing an image change its file size?",
      answer: "Yes, reducing image dimensions significantly decreases file size. A 4000x3000 image resized to 1920x1440 can be 75% smaller. This is ideal for web optimization and faster loading times."
    }
  ],
  "currency-converter": [
    {
      question: "How often are exchange rates updated?",
      answer: "Exchange rates are updated regularly to reflect current market values. For the most accurate conversions, especially for large amounts, verify rates with your bank or financial institution."
    },
    {
      question: "How many currencies are supported?",
      answer: "Our currency converter supports over 150 world currencies including USD, EUR, GBP, JPY, CNY, and all major and minor currencies. Cryptocurrency conversions may also be available."
    },
    {
      question: "Can I convert between multiple currencies at once?",
      answer: "You can convert one currency to another with a single conversion. For comparing multiple currencies, perform separate conversions or use our multi-currency comparison feature."
    },
    {
      question: "Are the conversions accurate for financial transactions?",
      answer: "Our rates are indicative and great for estimates. For actual financial transactions, check with your bank as they may add fees, spreads, or use slightly different rates."
    },
    {
      question: "Can I convert historical currency rates?",
      answer: "Our tool shows current exchange rates. For historical rate analysis, you may need specialized financial tools or historical data providers."
    }
  ],
  "hash-generator": [
    {
      question: "What is a hash and what is it used for?",
      answer: "A hash is a fixed-length string generated from input data using a mathematical algorithm. Hashes are used for data integrity verification, password storage, digital signatures, and creating unique identifiers for files or data."
    },
    {
      question: "What's the difference between SHA-256 and SHA-512?",
      answer: "SHA-256 produces a 256-bit (64-character) hash, while SHA-512 produces a 512-bit (128-character) hash. SHA-512 is more secure but slower. SHA-256 is sufficient for most applications and is widely used in cryptocurrencies like Bitcoin."
    },
    {
      question: "Can I reverse a hash to get the original text?",
      answer: "No, hashes are one-way functions by design. You cannot mathematically reverse a hash to retrieve the original input. This property makes hashes ideal for storing passwords—only the hash is stored, not the actual password."
    },
    {
      question: "Why does the same input always produce the same hash?",
      answer: "Hash functions are deterministic—identical inputs always produce identical outputs. This consistency is essential for verification purposes. If you hash a file twice, getting the same result confirms the file hasn't changed."
    },
    {
      question: "Is SHA-1 still secure to use?",
      answer: "SHA-1 is considered cryptographically weak and shouldn't be used for security purposes. Collision attacks have been demonstrated. Use SHA-256 or SHA-512 for security-critical applications. SHA-1 is only acceptable for non-security uses like checksums."
    }
  ],
  "color-picker": [
    {
      question: "What color formats are supported?",
      answer: "Our color picker supports HEX, RGB, HSL, HSV, and CMYK formats. You can easily convert between formats and copy the color code you need for your project."
    },
    {
      question: "Can I pick colors from an image?",
      answer: "Yes, use our image color picker tool to extract colors from any uploaded image. Click anywhere on the image to get the exact color code at that point."
    },
    {
      question: "How do I find complementary colors?",
      answer: "Use our color harmonies feature to find complementary, analogous, triadic, and other color relationships. This helps create visually pleasing color schemes for designs."
    },
    {
      question: "Is the color picker accessible for colorblind users?",
      answer: "Yes, we provide color codes in multiple formats (HEX, RGB) and color names where possible, making it accessible for users with color vision deficiencies."
    },
    {
      question: "Can I save colors for later use?",
      answer: "You can copy color codes to your clipboard for immediate use. For saving color palettes, use our palette generator tool which allows you to export and share color collections."
    }
  ],
  "text-diff": [
    {
      question: "How does the text diff checker work?",
      answer: "Our diff checker compares two texts character by character or line by line, highlighting additions in green, deletions in red, and unchanged content in normal text. It shows exactly what changed between versions."
    },
    {
      question: "Can I compare code files?",
      answer: "Yes, our diff checker works excellently for comparing code files. It preserves formatting, whitespace, and syntax, making it ideal for reviewing code changes and merge conflicts."
    },
    {
      question: "What's the maximum text length for comparison?",
      answer: "You can compare texts of several thousand lines. For very large files, processing may take a moment. All comparison happens locally in your browser."
    },
    {
      question: "Can I download or export the diff results?",
      answer: "You can copy the highlighted diff output for use in documents or reports. The visual comparison helps communicate changes clearly to team members."
    },
    {
      question: "Does it work with all languages and character sets?",
      answer: "Yes, our diff checker supports all languages, special characters, and Unicode text. It works equally well with English, Chinese, Arabic, code, and any other text content."
    }
  ],
  "uuid-generator": [
    {
      question: "What is a UUID and why do I need it?",
      answer: "UUID (Universally Unique Identifier) is a 128-bit identifier that's statistically guaranteed to be unique. Use UUIDs for database primary keys, session IDs, file names, and any scenario requiring unique identification."
    },
    {
      question: "What UUID versions do you support?",
      answer: "We support UUID v4 (random), which is the most commonly used version for general purposes. UUID v4 uses random numbers, making it ideal for most applications."
    },
    {
      question: "How unique are generated UUIDs?",
      answer: "UUID v4 has 122 random bits, providing about 5.3 x 10^36 possible combinations. The probability of generating duplicate UUIDs is practically zero—less than winning the lottery multiple times."
    },
    {
      question: "Can I generate multiple UUIDs at once?",
      answer: "Yes, you can generate multiple UUIDs simultaneously. Specify how many you need and get them all instantly, perfect for seeding databases or batch operations."
    },
    {
      question: "Are the UUIDs cryptographically secure?",
      answer: "Our generator uses cryptographically secure random number generation (CSPRNG), making the UUIDs suitable for security-sensitive applications like session tokens."
    }
  ],
  "hash-generator": [
    {
      question: "What hash algorithms are supported?",
      answer: "We support MD5, SHA-1, SHA-256, SHA-384, SHA-512, and other common algorithms. SHA-256 is recommended for most security applications as MD5 and SHA-1 are considered weak."
    },
    {
      question: "Can I hash files as well as text?",
      answer: "Yes, you can hash both text input and uploaded files. File hashing is useful for verifying downloads, checking file integrity, and comparing file contents."
    },
    {
      question: "Is the hash generated securely?",
      answer: "Yes, all hashing is done locally in your browser using standard cryptographic libraries. Your input data is never sent to our servers."
    },
    {
      question: "What's the difference between hashing and encryption?",
      answer: "Hashing is one-way—you cannot recover original data from a hash. Encryption is two-way with a key. Use hashing for verification and integrity; use encryption when you need to retrieve original data."
    },
    {
      question: "Which hash algorithm should I use?",
      answer: "For security purposes, use SHA-256 or SHA-512. For checksums and non-security purposes, MD5 or SHA-1 are faster but less secure. Never use MD5 for password hashing."
    }
  ],
  "url-encoder": [
    {
      question: "What characters need to be URL encoded?",
      answer: "Special characters like spaces, &, =, ?, #, /, and non-ASCII characters must be encoded for use in URLs. Our encoder handles all necessary conversions automatically."
    },
    {
      question: "What's the difference between encoding and decoding?",
      answer: "Encoding converts special characters to safe URL format (e.g., space becomes %20). Decoding reverses this, converting %20 back to space. Use encoding when creating URLs, decoding when reading them."
    },
    {
      question: "Can I encode entire URLs or just parameters?",
      answer: "Typically, you only encode parameter values, not the entire URL structure. Encoding the full URL would make it invalid. Our tool handles this correctly for common use cases."
    },
    {
      question: "Why do I need URL encoding?",
      answer: "URLs can only contain certain safe characters. Without encoding, special characters could break the URL or be misinterpreted by browsers and servers. Encoding ensures data is transmitted correctly."
    },
    {
      question: "Is URL encoding the same as HTML encoding?",
      answer: "No, they're different. URL encoding uses percent-encoding (%20 for space), while HTML encoding uses entities (&nbsp; for space). Use the right type for your context."
    }
  ],
  "regex-tester": [
    {
      question: "What regex flavors are supported?",
      answer: "Our tester uses JavaScript's regex engine, which supports most common regex features including lookahead, lookbehind, capturing groups, and Unicode support."
    },
    {
      question: "Can I test regex with multiple test strings?",
      answer: "Yes, enter multiple test strings to see how your pattern matches against each one. This helps verify your regex works correctly for all expected inputs."
    },
    {
      question: "How do I debug a complex regex?",
      answer: "Our tester highlights matches in real-time, shows captured groups, and indicates where matches fail. Use the explanation feature to understand what each part of your pattern does."
    },
    {
      question: "What are common regex patterns I can use?",
      answer: "Common patterns include email validation, phone numbers, URLs, dates, and IP addresses. Check our pattern library for ready-to-use regex for common validation tasks."
    },
    {
      question: "Are there any regex features not supported?",
      answer: "JavaScript regex doesn't support some features from PCRE like recursive patterns or conditional expressions. However, most common regex needs are fully supported."
    }
  ],
  "timestamp-converter": [
    {
      question: "What is a Unix timestamp?",
      answer: "A Unix timestamp is the number of seconds (or milliseconds) since January 1, 1970 UTC. It's a universal way to represent time that works across all programming languages and systems."
    },
    {
      question: "How do I convert between timestamp formats?",
      answer: "Enter your timestamp and our tool instantly converts it to human-readable date/time. You can also enter a date to get its Unix timestamp in seconds or milliseconds."
    },
    {
      question: "What's the difference between seconds and milliseconds timestamps?",
      answer: "Seconds timestamps are 10 digits (e.g., 1700000000), while milliseconds are 13 digits (e.g., 1700000000000). Our tool auto-detects the format and converts correctly."
    },
    {
      question: "How do I handle timezone differences?",
      answer: "Unix timestamps are always in UTC. Our tool shows the equivalent time in your local timezone and allows conversion to any timezone for comparison."
    },
    {
      question: "What date formats can I convert to timestamps?",
      answer: "We support various formats including ISO 8601, common date strings, and locale-specific formats. The converter automatically parses and converts your input."
    }
  ],
  "markdown-html": [
    {
      question: "What Markdown syntax is supported?",
      answer: "We support standard Markdown including headers, bold, italic, links, images, code blocks, lists, tables, blockquotes, and GitHub Flavored Markdown (GFM) extensions."
    },
    {
      question: "Can I preview the HTML output in real-time?",
      answer: "Yes, our converter shows live HTML preview as you type. You can see exactly how your Markdown will render before copying or using the output."
    },
    {
      question: "Is the generated HTML clean and semantic?",
      answer: "Yes, we generate clean, semantic HTML5 without unnecessary inline styles or wrapper divs. The output is optimized for accessibility and modern web standards."
    },
    {
      question: "Can I convert HTML back to Markdown?",
      answer: "Yes, our tool supports bidirectional conversion. You can convert Markdown to HTML and HTML back to Markdown, useful for migrating content between systems."
    },
    {
      question: "Does it support syntax highlighting for code blocks?",
      answer: "Code blocks are converted with appropriate language classes for syntax highlighting. You can add CSS or use libraries like Prism.js to enable colorized code display."
    }
  ],
  "image-cropper": [
    {
      question: "Can I crop to specific aspect ratios?",
      answer: "Yes, choose from preset ratios like 1:1 (square), 16:9 (widescreen), 4:3, or set a custom ratio. This ensures your crops are perfect for specific uses like social media or print."
    },
    {
      question: "How do I crop a circular or rounded image?",
      answer: "First crop your image to a square (1:1 ratio), then use our round corners tool to add border radius. For a perfect circle, use 50% border radius on a square crop."
    },
    {
      question: "Can I adjust the crop area precisely?",
      answer: "Yes, drag the crop handles to adjust size, or enter specific pixel dimensions for exact control. You can also drag the entire crop area to reposition it on the image."
    },
    {
      question: "Does cropping reduce image quality?",
      answer: "Cropping removes parts of the image but doesn't reduce quality of the remaining area. The cropped section retains its original resolution and quality."
    },
    {
      question: "What's the maximum image size I can crop?",
      answer: "Our cropper handles images up to 10MB. Processing happens locally in your browser, so very large images may take a moment to load but will work correctly."
    }
  ],
  "percentage-calculator": [
    {
      question: "How do I calculate a percentage of a number?",
      answer: "Enter the percentage and the number to find the result. For example, 20% of 150 = 30. The formula is: (percentage / 100) × number."
    },
    {
      question: "How do I find what percentage one number is of another?",
      answer: "Divide the first number by the second and multiply by 100. For example, what percent is 30 of 150? Answer: (30 / 150) × 100 = 20%."
    },
    {
      question: "How do I calculate percentage increase or decrease?",
      answer: "Use the formula: ((new value - old value) / old value) × 100. A positive result is an increase; negative is a decrease. Example: 100 to 120 = 20% increase."
    },
    {
      question: "Can I calculate reverse percentages?",
      answer: "Yes, if you know the final amount after a percentage change, you can calculate the original. For example, if 120 is 120% of the original, the original was 120 / 1.2 = 100."
    },
    {
      question: "What are common percentage calculations?",
      answer: "Common uses include discounts (original price × discount%), tips (bill × tip%), tax (subtotal × tax rate), and grade percentages (score / total × 100)."
    }
  ],
  "loan-calculator": [
    {
      question: "How is the monthly payment calculated?",
      answer: "Monthly payments use the amortization formula considering principal, interest rate, and loan term. Higher interest or longer terms mean higher total interest paid over the life of the loan."
    },
    {
      question: "What's the difference between APR and interest rate?",
      answer: "Interest rate is just the cost of borrowing the principal. APR (Annual Percentage Rate) includes interest plus fees and other charges, giving a more complete picture of loan cost."
    },
    {
      question: "How can I pay off my loan faster?",
      answer: "Make extra payments toward principal, round up monthly payments, or make bi-weekly payments instead of monthly. Even small extra payments significantly reduce total interest paid."
    },
    {
      question: "What factors affect my loan payment?",
      answer: "Principal amount, interest rate, loan term, and payment frequency all affect monthly payments. A lower rate or shorter term reduces total interest but increases monthly payments."
    },
    {
      question: "Can I calculate different loan scenarios?",
      answer: "Yes, adjust any variable to see how it affects your payment. Compare 15-year vs 30-year terms, different rates, or extra payments to find the best option for your budget."
    }
  ],
  "age-calculator": [
    {
      question: "How does the age calculator work?",
      answer: "Enter your birth date and the calculator shows your exact age in years, months, days, hours, and even minutes. It accounts for leap years and varying month lengths."
    },
    {
      question: "Can I calculate age between two dates?",
      answer: "Yes, enter any two dates to find the exact duration between them. This works for calculating how old someone was at a specific date or time between events."
    },
    {
      question: "Does it account for leap years?",
      answer: "Yes, our calculator correctly handles leap years, including the edge case of being born on February 29th. It shows accurate age regardless of birth date."
    },
    {
      question: "Can I find my age in weeks or days?",
      answer: "Yes, the calculator shows age in multiple units: years, months, weeks, days, hours, and minutes. You can see exactly how many days old you are."
    },
    {
      question: "What's the age calculation for legal purposes?",
      answer: "For legal age calculations, most jurisdictions count full years completed. You turn 18 at the start of your 18th birthday, not 18 years after your birth moment."
    }
  ]
};
